package com.sofkaU.Taller1;
import java.util.Scanner;

public class puntos {
    public String name,lastName,nameM,lastNameM;
    public String nameF,lastNameF,capital,country;
    public int age,ageP;
    public double height;
    public String nameP,type,nameO;
    private Scanner entry=new Scanner(System.in);


    public void punto1(){
        
        System.out.println("Ingrese su nombre");
        name=entry.nextLine();
        
        //Scanner entryL=new Scanner(System.in);
        System.out.println("Ingrese su apellido");
        lastName = entry.nextLine();
        
 
    }
    public void punto2(){
        Scanner entryN=new Scanner(System.in);
        System.out.println("Ingrese su nombre");
        name=entryN.nextLine();
        
        Scanner entryL=new Scanner(System.in);
        System.out.println("Ingrese su apellido");
        lastName=entryL.nextLine();
        
        Scanner entryA=new Scanner(System.in);
        System.out.println("Ingrese su edad");
        age=entryA.nextInt();
        
        Scanner entryH=new Scanner(System.in);
        System.out.println("Ingrese su estatura");
        height=entryH.nextInt();
       
    }
    
    public void punto3(){
        Scanner entryN=new Scanner(System.in);
        System.out.println("Ingrese su nombre ");
        name=entryN.nextLine();
        
        Scanner entryL=new Scanner(System.in);
        System.out.println("Ingrese su apellido ");
        lastName=entryL.nextLine();
        
        Scanner entryM=new Scanner(System.in);
        System.out.println("Ingrese el nombre de su madre ");
        nameM=entryN.nextLine();
        
        Scanner entryLM=new Scanner(System.in);
        System.out.println("Ingrese su apellido de la madre ");
        lastNameM=entryL.nextLine();
        
        Scanner entryF=new Scanner(System.in);
        System.out.println("Ingrese el nombre de su papa ");
        nameF=entryN.nextLine();
        
        Scanner entryLF=new Scanner(System.in);
        System.out.println("Ingrese el apellido del padre ");
        lastNameF=entryL.nextLine();
    }
     public void punto4(){
        Scanner entry=new Scanner(System.in);
        System.out.println("Ingrese la cuidad");
        capital=entry.nextLine();
        
        Scanner entryL=new Scanner(System.in);
        System.out.println("Ingrese el País");
        country=entryL.nextLine();
    }   
    public void punto5(){
        Scanner entryP=new Scanner(System.in);
        System.out.println("Ingrese el nombre de la mascota ");
        nameP=entryP.nextLine();
        
        Scanner entryT=new Scanner(System.in);
        System.out.println("Cual es el tipo de la mascota ");
        type=entryT.nextLine();
        
        Scanner entryA=new Scanner(System.in);
        System.out.println("Ingrese su edad ");
        ageP=entryA.nextInt();
        
        Scanner entryO=new Scanner(System.in);
        System.out.println("Ingrese el nombre del dueño ");
        nameO=entryO.nextLine();
    }
}