package com.sofkaU.Taller1;
public class Main {
    
    
    public static void main(String[] args) {
        puntos p1=new puntos();
        p1.punto1();
        System.out.println("su nombre es: "+ p1.name);
        System.out.println("su apellido es: "+ p1.lastName);
        System.out.println(" ");
        
        puntos p2=new puntos();
        p2.punto2();
        System.out.println("su nombre es: " + p2.name);
        System.out.println("su apellido es: "+ p2.lastName);
        System.out.println("su edad es: " + p2.age);
        System.out.println("su altura es: "+ p2.height);
        System.out.println(" ");
        
        puntos p3=new puntos();
        p3.punto3();
        System.out.println("Yo"+p3.name+p3.lastName+" soy hijo de"+ p3.nameF+p3.lastNameF+" y"+p3.nameM+p3.lastNameM);
        System.out.println("su nombre es: " + p3.nameM+  p3.lastNameM);
        System.out.println("su nombre es: " + p3.nameF+  p3.lastNameF);
        System.out.println(" ");
        
        puntos p4 = new puntos();
        p4.punto4();
        System.out.println("La ciudad"+ p4.capital+ "es la capital del país"+p4.country);
        System.out.println(" ");
        
        puntos p5 = new puntos();
        p5.punto5();
        System.out.println(p4.nameP+" es un(a) "+ p4.type+" , el cual, tiene"+p4.ageP+" años de edad y"
        +p4.nameO+" es su dueño");
        System.out.println(" ");
}


}


