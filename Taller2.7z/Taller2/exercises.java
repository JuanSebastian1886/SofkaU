package com.sofkaU.Taller2;

import java.util.Scanner;

public class exercises {

    public String name, lastName, movies, rent, devo;
    public String movie, tip, suggestion, products;
    public String enter, remarks, exit, parts;
    public int age, option, i, lim;
    public double height, prices, weight, imc, lengthL, lengthM, area, amount, total;
    public double retires;
    public boolean control;
    private Scanner entry = new Scanner(System.in);
    private Scanner entryA = new Scanner(System.in);
    private Scanner entryB = new Scanner(System.in);
    private Scanner entryC = new Scanner(System.in);

    public void punto1() {
        System.out.println("Ingrese su edad: ");
        age = entry.nextInt();

        if (age >= 18) {
            System.out.println("Usted es mayor de edad ");
        } else {
            System.out.println("Usted aún es niño ");
        }
    }

    public void punto3() {
        System.out.println("Ingrese su nombre: ");
        name = entry.nextLine();
        System.out.println("Ingrese sus apellidos: ");
        lastName = entry.nextLine();
        System.out.println("Ingrese su edad: ");
        age = entry.nextInt();

        if (age >= 18) {
            System.out.println(name + " " + lastName + " ,usted es mayor de edad"
                    + ", por lo tanto puede entrar a la fiesta. ");
        } else {
            System.out.println(name + " " + lastName + " ,usted es menor de edad, por lo tanto"
                    + ", no puede entrar a la fiesta, por favor devuélvase a su casa.");
        }
    }

    public void punto4() {

        while (control = true) {

            System.out.println("Elija una opcion del menú ");
            System.out.println("1. Alquilar pelicula ");
            System.out.println("2. Consultar peliculas disponibles");
            System.out.println("3. Entregar pelicula, desea hacer una sugerencia s/n? ");
            option = entry.nextInt();

            String movies[] = new String[3];
            movies[0] = "Armagedon";
            movies[1] = "Duro de matar";
            movies[2] = "Spiderman";
            control = true;

            switch (option) {

                case 1: {
                    System.out.println("Que pelicula desea alquilar de las que estan disponibles? ");
                    rent = entryA.nextLine();
                    System.out.println("La pelicula rentada fue:  " + rent);
                    break;
                }
                case 2: {
                    System.out.println("Peliculas disponibles? ");
                    if (rent.equals("Armagedon")) {
                        movies[0] = "Pelicula Armagedon rentada";
                    }
                    if (rent.equals("Duro de matar")) {
                        movies[1] = "Pelicula Duro de matar rentada";
                    }
                    if (rent.equals ("Spiderman")) {
                        movies[2] = "Pelicula Spiderman rentada";
                    }
                    System.out.println(movies[0]);
                    System.out.println(movies[1]);
                    System.out.println(movies[2]);
                    break;
                }

                case 3: {
                    System.out.println("Ingrese el nombre de la pelicula a regresar");
                    movie = entryA.nextLine();
                    System.out.println("Desea hacer una anotacion sobre la pelicula a regresar? si/no");
                    tip = entryA.nextLine();

                    if (tip.equals("si")) {
                        System.out.println("Cual es su sugerencia o anotación");
                        suggestion = entryA.nextLine();
                        System.out.println("La pelicula regresada fue " + movie + " y la sugerencia es: " + suggestion);
                    } else {
                        System.out.println("La pelicula regresada fue " + movie);
                    }
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entry.nextBoolean();
            if (control == false) {
                break;
            }
        }
    }

    public void punto5() {
        while (control = true) {

            System.out.println("Elija una opcion del menú ");
            System.out.println("1. Compra de productos ");
            System.out.println("2. Consultar precios");
            System.out.println("3. Devoluciones ");
            option = entry.nextInt();

            int prices[] = new int[3];
            prices[0] = 5350;
            prices[1] = 6000;
            prices[2] = 6400;
            control = true;

            switch (option) {

                case 1: {
                    System.out.println("Los productos disponibles son: ");
                    System.out.println("Acetaminofen, Amoxicilina, Dolex, que desea llevar? ");
                    products = entryA.nextLine();
                    System.out.println("El/los productos comprados fue/ron:  " + products);
                    break;
                }
                case 2: {
                    System.out.println("El precio de la Acetaminofen es: ");
                    System.out.println(prices[0]);
                    System.out.println("El precio de la Amoxicilina es: ");
                    System.out.println(prices[1]);
                    System.out.println("El precio de la Dolex es: ");
                    System.out.println(prices[2]);
                    break;
                }

                case 3: {
                    System.out.println("Ingrese el nombre del(os) medicamento(s) a devover y el porque de la devoluciòn");
                    devo = entryA.nextLine();
                    System.out.println("el(los) medicamento(s) regresados y el porque de la devoluciòn es : " + devo);
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }

    }

    public void punto6() {
        while (control = true) {

            System.out.println("Elija una opcion del menú ");
            System.out.println("1. Registro del ingreso al taller ");
            System.out.println("2. Registro de salida del taller");
            System.out.println("3. Arreglos hechos por el mecánico ");
            option = entry.nextInt();

            String name[] = new String[3];
            String enter[] = new String[3];
            String remarks[] = new String[3];

            control = true;

            switch (option) {

                case 1: {
                    System.out.println("Cuantos motocicletas se  regitran?");
                    lim = entryA.nextInt();
                    for (int i = 0; i <= lim - 1; i++) {
                        System.out.println("Es un ingreso al taller?, si/no ");
                        enter[i] = entryB.nextLine();
                        System.out.println("Indique el nombre de la motocicleta ");
                        name[i] = entryB.nextLine();
                        System.out.println("Desea agregar observaciones?, si/no ");
                        remarks[i] = entryB.nextLine();
                        if (remarks[i].equals("si")) {

                            System.out.println("Cuales son las observaciones? ");
                            suggestion = entryC.nextLine();
                            System.out.println("Las observaciones ingresadas son: "+suggestion);
                        } else {
                            System.out.println("No se dejan observaciones ");
                        }
                        if (enter[i].equals("si")) {

                            System.out.println("La motocicleta " + name[i] + " ingresa al taller "+" con las observaciones: "+suggestion);
                        } else {
                            System.out.println("La motocicleta" + name[i] + " actualmente no ha ingresado al taller ");
                        }
                    }
                    break;
                }
                case 2: {
                    System.out.println("Sepresenta alguna salida de motocicletas?, si/no ");
                    exit = entryB.nextLine();
                    if (exit.equals("si")) {
                        System.out.println("Indique el nombre de la motocicleta ");
                        name[i] = entryB.nextLine();
                        System.out.println("La motocicleta" + name[i] + " sale del taller ");
                    } else {
                        System.out.println("La motocicleta" + name[i] + " aun esta en taller ");
                    }
                    break;
                }

                case 3: {
                    System.out.println("La motocicleta fue necesario cambiar o añadir piezas?, si/no ");
                    parts = entryB.nextLine();
                    if (parts == "si") {
                        System.out.println("Que piezas fueron reemplazadas ");
                        products = entryB.nextLine();
                        System.out.println("Las piezas reemplazas fueron:" + parts + " ,descontar del inventario");
                    } else {
                        System.out.println("No fue necesario reemplazar piezas ");
                    }
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }

    }

    public void punto7() {
        System.out.println("Ingrese su nombre: ");
        name = entry.nextLine();
        System.out.println("Ingrese sus apellidos: ");
        lastName = entry.nextLine();
        System.out.println("Ingrese su edad: ");
        age = entry.nextInt();
        System.out.println("Indique su peso en Kilogramos (Kg) ");
        weight = entry.nextDouble();
        System.out.println("Indique su altuta em metros (m) ");
        height = entry.nextDouble();

        imc = weight / (height * height);
        System.out.println(name + " " + lastName + " con edad de: " + age
                + " años " + "tiene un Índice de masa corporal de: " + imc);

        if (imc < 18.5) {
            System.out.println(name + " " + lastName + "  usted esta bajo de peso");
        } else if (18.5 <= imc && imc <= 24.9) {
            System.out.println(name + " " + lastName + "  usted tiene un peso idoneo");
        } else if (25 <= imc && imc <= 29.9) {
            System.out.println(name + " " + lastName + "  usted tiene sobrepeso");
        } else if (imc >= 30) {
            System.out.println(name + " " + lastName + "  usted obesidad");
        }
    }

    public void punto8() {
        while (control = true) {

            System.out.println("Solo se reciben 5 pedidos al día");
            System.out.println("1. Registrar los pedidos ");
            System.out.println("2. Tortas disponibles");
            System.out.println("3. Ventas del día ");
            option = entry.nextInt();

            String name[] = new String[5];
            String remarks[] = new String[5];
            String products[] = new String[5];

            control = true;

            switch (option) {

                case 1: {
                    System.out.println("Ingrese el numero de pedidos del día ");
                    lim = entryA.nextInt();

                    if (lim <= 5) {
                        for (i = 0; i <= lim - 1; i++) {
                            System.out.println("Ingrese el nombre de la persona que hace el pedido ");
                            name[i] = entryB.nextLine();
                            System.out.println("Que torta ordeno? ");
                            products[i] = entryB.nextLine();
                            System.out.println("Desea agregar observaciones?, si/no: ");
                            remarks[i] = entryB.nextLine();

                            if (remarks[i] == "si") {
                                System.out.println("Ingrese las observaciones");
                                suggestion = entryC.nextLine();
                                System.out.println("El cliente" + name[i] + " ordeno " + products[i]
                                        + " " + "y sus obsevaciones son: " + suggestion);
                            } else {
                                System.out.println("No se deja observaciones" + "El cliente" + name[i] + " ordeno " + products[i]);
                            }
                        }
                    }
                    break;
                }
                case 2: {

                    System.out.println("Torta Red Velvet es de 8 porciones decorada con crema de limón con precio de 16.000");
                    System.out.println("");
                    System.out.println("Torta Envinada es de 8 porciones y no lleva decoración con precio de 22.000");
                    System.out.println("");
                    System.out.println("Torta Maria Luisa de arequipe es de 8 porciones decorada con frutos rojos con precio de 10.500");
                    System.out.println("");
                    break;
                }

                case 3: {
                    int enter[] = new int[3];

                    System.out.println("Si alguna referencia no fue vendida poner 0");
                    System.out.println("");
                    System.out.println("Ingrese la catidad de tortas de cake1 vendidas");
                    enter[0] = entryC.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese la catidad de tortas de cake2 vendidas");
                    enter[1] = entryC.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese la catidad de tortas de cake3 vendidas");
                    enter[2] = entryC.nextInt();
                    System.out.println("");

                    double prices[] = new double[4];
                    prices[0] = enter[0] * 16000;
                    prices[1] = enter[1] * 22000;
                    prices[2] = enter[2] * 10500;
                    prices[3] = prices[0] + prices[1] + prices[2];

                    System.out.println("Las ventas netas del día fueron:");
                    System.out.println("Las tortas de Red Velvet: " + prices[0]);
                    System.out.println("Las tortas Envinadas: " + prices[1]);
                    System.out.println("Las tortas Maria Luisa: " + prices[2]);
                    System.out.println("El total vendido del día fue  " + prices[3]);
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }

    }

    public void punto9() {
        while (control = true) {

            System.out.println("Elija una opción");
            System.out.println("1. Calcular área de un rectángulo ");
            System.out.println("2. Calcular área de un triángulo");
            System.out.println("3. Calcular área de un trapecio ");
            option = entry.nextInt();

            control = true;

            switch (option) {
                case 1: {
                    System.out.println("Ingrese la longitud del rectángulo en cm");
                    lengthL = entryA.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese el ancho del rectángulo en cm");
                    height = entryA.nextInt();
                    System.out.println("");
                    area = height * lengthL;
                    System.out.println("El área del rectángulo es: " + area + " cm^2");
                    break;
                }

                case 2: {
                    System.out.println("Ingrese la base del triángulo en cm");
                    lengthL = entryA.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese la altura del triángulo en cm");
                    height = entryA.nextInt();
                    System.out.println("");
                    area = (height * lengthL) / 2;
                    System.out.println("El área del triángulo es: " + area + " cm^2");
                    break;
                }

                case 3: {
                    System.out.println("Ingrese la base menor del trapecio en cm");
                    lengthL = entryA.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese la base mayor del trapecio en cm");
                    lengthM = entryA.nextInt();
                    System.out.println("");
                    System.out.println("Ingrese la altura del trapecio en cm");
                    height = entryA.nextInt();
                    System.out.println("");
                    area = (height * (lengthL + lengthM)) / 2;
                    System.out.println("El área del trapecio es: " + area + " cm^2");
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }
    }

    public void punto10() {
        this.amount = 0;
        double amount[] = new double[4];
        double retires[] = new double[2];
        control = true;
        amount[0] = 0;
        amount[1] = 0;
        amount[2] = 0;
        amount[3] = 0;

        retires[0] = 0;
        retires[1] = 0;
        // retires[2]=0;
        // retires[3]=0;

        while (control == true) {

            System.out.println("Elija una opción");
            System.out.println("1. Desea realizar una consignacion ");
            System.out.println("2. Desea realizar un retiro");
            System.out.println("3. Consultar saldo ");
            option = entry.nextInt();

            switch (option) {
                case 1: {
                    System.out.println("Se permiten realizar tres consignaciones día ");
                    System.out.println(" ");

                    for (i = 0; i <= 2; i++) {
                        System.out.println(" Ingrese la cantidad de dinero a consignar ");
                        amount[i] = entryB.nextDouble();

                        System.out.println(" ");
                        if (amount[i] < 0) {
                            System.out.println("El valor ingresado no puede ser negativo!");
                            System.out.println("");
                            i--;
                        } else {
                            this.amount += amount[i];
                            System.out.println(" Su nuevo saldo es: " + this.amount);
                        }

                    }
                    break;
                }

                case 2: {
                    for (i = 0; i <= 1; i++) {
                        System.out.println(" Ingrese la cantidad de dinero a retirar ");
                        retires[i] = entryB.nextDouble();

                        if (retires[i] > 0 && this.amount > 0 && retires[i] <= this.amount) {
                            this.amount -= retires[i];
                            System.out.println(" Su saldo es: " + this.amount);
                        } else {
                            System.out.println(" No posee saldo para retirar ");

                        }

                        break;
                    }
                }

                case 3: {
                    System.out.println(" Su saldo es: " + this.amount);
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }
    }
}
