package com.sofkaU.Taller2;
import java.util.Scanner;

public class Main {
    
    public static int option;
    public static boolean control;
    
    public static void main(String[] args){
    Scanner entry = new Scanner(System.in);
    System.out.println("Menú de puntos ");
    System.out.println("1. Puntos 1 y 2 ");
    System.out.println("2. Punto 3 ");
    System.out.println("3. Punto 4  ");
    System.out.println("4. Punto 5  ");
    System.out.println("5. Punto 6  ");
    System.out.println("6. Punto 7  ");
    System.out.println("7. Punto 8  ");
    System.out.println("8. Punto 9  ");
    System.out.println("9. Punto 10  ");
    System.out.println(" ");
    control=true;
    
    
    while (control==true){
        
        System.out.println("Desea ver algún punto?, true/false ");
        control = entry.nextBoolean();
        System.out.println("");
        if (control==false){
            break;
        }
            System.out.println("Ingrese la opción que desea: ");
            option = entry.nextInt();
            
            switch (option) {

                 case 1: {
                    exercises p1 = new exercises();
                    p1.punto1();
                    break;
                }
                case 2: {
                    exercises p3 = new exercises();
                    p3.punto3();
                    break;

                }
                case 3: {
                    exercises p4 = new exercises();
                    p4.punto4();
                    break;

                }

                case 4: {
                    exercises p5 = new exercises();
                    p5.punto5();
                    break;

                }
                case 5: {
                    exercises p6 = new exercises();
                    p6.punto6();
                    break;

                }
                case 6: {
                    exercises p7 = new exercises();
                    p7.punto7();
                    break;

                }
                case 7: {
                    exercises p8 = new exercises();
                    p8.punto8();
                    break;

                }
                case 8: {
                    exercises p9 = new exercises();
                    p9.punto9();
                    break;

                }
                case 9: {
                    exercises p10 = new exercises();
                    p10.punto10();
                    break;

                }

                default:
                    System.out.println("Opcion no valida");

            }
       
        } 

    }
}
