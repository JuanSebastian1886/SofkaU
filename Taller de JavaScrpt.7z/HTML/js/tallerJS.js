const changeColorViolet =(id) =>{
    let element= document.querySelector(`#${id}`)
    element.classList.add("fond1")
}
const changeColorGray =(id) =>{
    let element= document.querySelector(`#${id}`)
    element.classList.add("fondPpal")
}
const changeColorRed =(id) =>{
    let element= document.querySelector(`#${id}`)
    element.classList.add("fond2")
}
const removeStyle =(id,style) =>{
    let element= document.querySelector(`#${id}`)
    element.classList.remove(style)
}

const main=()=>{
let elementAccordion= document.getElementsByClassName("accordion");
console.log(elementAccordion)
      for (let i = 0; i< elementAccordion.length; i++){
        elementAccordion[i].addEventListener("click",function(){
          this.classList.toggle("active");
          console.log(elementAccordion[i])
          let panel = this.nextElementSibling;
          console.log(panel)
          if (panel.style.display == "block") {
            panel.style.display = "none";
          } else {
            panel.style.display = "block";
          }
        });
      }
      }
      