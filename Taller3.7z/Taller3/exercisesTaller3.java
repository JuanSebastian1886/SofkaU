package com.sofkaU.Taller3;

import java.util.*;

public class exercisesTaller3 {

    public String name, company, s, brand, plate;
    public int option, i, j, k, n, phone, search;
    public boolean control;
    private Scanner entry = new Scanner(System.in);
    private Scanner entryA = new Scanner(System.in);
    private Scanner entryB = new Scanner(System.in);
    private Scanner entryC = new Scanner(System.in);
    private Scanner entryD = new Scanner(System.in);

    public void punto1() {
        System.out.println("Ingrese la altura ");
        n = entry.nextInt();

        for (int x = 1; x <= n; x++) {
            for (int i = 1; i <= x; i++) {
                System.out.print("* ");
            }
            System.out.println("");
        }
    }

    public void punto2() {
        System.out.println("Ingrese la altura ");
        n = entry.nextInt();

        for (int j = 1; j <= n; j++) {
            for (int i = 1; i <= n - j; i++) {
                System.out.print("  ");
            }

            for (int k = 1; k <= j; k++) {
                System.out.print("* ");
            }

            System.out.println();
        }
    }

    public void punto3() {

        n = 8;
        for (i = 1; i < n + (n / 2); i++) {
            for (j = n + (n / 2); j > i; j--) {
                System.out.print(" ");
            }
            for (k = 1; k <= 2 * i - 1; k++) {
                System.out.print("*");
            }
            System.out.println("");
        }
        for (i = 1; i < n - (n / 2); i++) {
            for (j = n + (n / 2); j > 1; j--) {
                System.out.print(" ");
            }
            for (k = n / 2; k <= (n / 2) + 1; k++) {
                System.out.print("*");
            }
            System.out.println("");
        }
    }

    public void punto4() {
        System.out.println("Ingrese el número de la tabla de multiplicar que desea ");
        n = entry.nextInt();
        k = 0;
        for (int i = 1; i <= 10; i++) {
            j = n * i;
            k++;
            System.out.println("La tabla de multiplicar  " + k + "x" + n + " es igual a : " + j);
        }
        System.out.println("");
    }

    public void punto5() {
        control = true;
        while (control == true) {

            System.out.println("Menú de usuario ");
            System.out.println("1. Capturar nombre ");
            System.out.println("2. Saludar persona");
            System.out.println("3. Salir del sistema ");
            option = entry.nextInt();
            String name5[] = new String[1];

            switch (option) {

                case 1: {
                    System.out.println("Indique su nombre completo  ");
                    name5[0] = entryA.nextLine();
                    System.out.println("El suario ingresado fue: " + name5[0]);

                    break;
                }
                case 2: {
                    System.out.println("Hola! " + name5[0] + " , esperamos este bien ");
                    break;
                }

                case 3: {
                    System.out.println("Saliendo...");
                    control = false;
                    System.out.println("");
                    break;
                }
            }
        }
    }

    public void punto6() {
        control = true;
        String name[] = new String[3];
        int phone[] = new int[3];
        String company[] = new String[3];

        while (control == true) {

            System.out.println(" opcion del menú ");
            System.out.println("1. Añadir usuario ");
            System.out.println("2. Buscar usuario");
            System.out.println("3. Borrar usuario ");
            option = entry.nextInt();

            switch (option) {

                case 1: {

                    for (i = 0; i <= 2; i++) {
                        System.out.println("Indique el nombre completo del usuario ");
                        name[i] = entryA.nextLine();
                        System.out.println("Ingrese el numero de telefono ");
                        phone[i] = entryB.nextInt();
                        System.out.println("Indique la organizacíon a la que pertenece ");
                        company[i] = entryA.nextLine();

//                        if(phone[0]==phone[1] ){
//                            System.out.println("El numero ingresado ya esta registrado, ingresar uno ");
//                            System.out.println("");
//                            i--;
//                        }else{
//                        System.out.println("Ingrese el numero de telefono ");
//                        phone[i] = entryC.nextInt();
//                        }
                    }
                    for (i = 0; i <= 2; i++) {
                        System.out.println("El usuario numero " + i + 1 + "  es: " + name[i] + " con celular: " + phone[i]
                                + " perteneciente  a la compañia: " + company[i]);
                        System.out.println(" ");
                    }
                    break;
                }
                case 2: {

                    System.out.println("Ingrese el usuario que desea buscar por el telefono registrado ");
                    search = entryC.nextInt();
                    for (i = 0; i <= 2; i++) {

                        if (phone[i] == search) {
                            System.out.println("El usuario registrado con ese numero es: " + name[i]);
                            System.out.println("");
                        } else {
                            System.out.println(" Usuario no registrado");
                        }
                    }

                    break;
                }

                case 3: {
                    System.out.println("Que usuario desea borrar por el telefono registrado ");
                    search = entryB.nextInt();
                    for (i = 0; i <= 2; i++) {

                        if (search == phone[i]) {
                            System.out.println("El usuario borrado es: " + name[i]);
                            System.out.println("");
                            name[i] = "";
                            phone[i] = 0;
                            company[i] = "";
                        } else {
                            System.out.println(" Usuario no registrado");
                        }
                    }
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }

    }

    public void punto7() {

        String name[] = new String[5];
        int phone[] = new int[5];
        String brand[] = new String[5];
        String plate[] = new String[5];

        control = true;

        while (control == true) {

            System.out.println("Elija una opcion del menú ");
            System.out.println("1. Ingreso a parqueadero ");
            System.out.println("2. Retiro de parqueadero");
            System.out.println("3. Consultar vehiculo ");
            option = entry.nextInt();

            switch (option) {

                case 1: {

                    for (int i = 0; i <= 4; i++) {
                        System.out.println("Indique el nombre completo del usuario ");
                        name[i] = entryA.nextLine();
                        System.out.println("Ingrese el numero de telefono ");
                        phone[i] = entryB.nextInt();
                        System.out.println("Indique la placa del vehiculo ");
                        plate[i] = entryC.nextLine();
                        System.out.println("Indique la marca del vehiculo ");
                        brand[i] = entryC.nextLine();
                    }
                    for (i = 0; i <= 4; i++) {
                        System.out.println("El usuario numero " + i + 1 + "  es: " + name[i] + " con celular: " + phone[i]
                                + " es propietario del vehiculo con placa: " + plate[i]);
                        System.out.println(" ");
                    }
                    break;
                }
                case 2: {
                    System.out.println("Ingrese el vehiculo con placa a salir del parqueadero ");
                    s = entryC.nextLine();
                    for (i = 0; i <= 4; i++) {

                        if (plate[i].equals(s)) {
                            System.out.println("El vehiculo registrado es: " + plate[i] + " sale del parqueadero");
                            System.out.println("");
                            name[i] = "";
                            phone[i] = 0;
                            plate[i] = "";
                            brand[i] = "";
                        } else {
                            System.out.println(" Vehiculo no registrado");
                        }

                    }

                    break;
                }

                case 3: {
                    System.out.println("Ingrese el vehiculo que desea buscar por placa ");
                    s = entryC.nextLine();
                    for (i = 0; i <= 4; i++) {

                        if (plate[i].equals(s)) {
                            System.out.println("El vehiculo actualmente en parqueadero: " + plate[i]);
                            System.out.println("");
                        } else {
                            System.out.println(" Vehiculo no registrado");
                        }
                    }
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }
    }

    public void punto8() {

        String name[] = new String[8];
        int result[] = new int[8];
        String test[] = new String[8];

        control = true;

        while (control == true) {

            System.out.println("Menú de usuario");
            System.out.println("1. Registro de ingreso al curso ");
            System.out.println("2. Registro de usuarios");
            System.out.println("3. Resultados ");
            option = entry.nextInt();

            switch (option) {

                case 1: {

                    for (int i = 0; i <= 7; i++) {
                        System.out.println("Indique el nombre completo del usuario ");
                        name[i] = entryA.nextLine();
                        System.out.println("Presento la prueba?, si/no ");
                        test[i] = entryA.nextLine();
                        System.out.println("Si presento la prueba, indique el puntaje obtenido, sino marque 0 ");
                        result[i] = entryC.nextInt();

                    }
                    break;
                }
                case 2: {
                    System.out.println("Registros de usuarios  ");
                    for (i = 0; i <= 7; i++) {

                        if (test[i].equals("si")) {
                            System.out.println("Los usuarios que presentaron la prueba son: " + name[i]);
                            System.out.println(" ");                                            
                        } else {
                            System.out.println(" Usuarios no registrados");
                        }
                    }
                    break;
                }

                case 3: {
                    System.out.println("Resultados de los examenes ");
                    s = entryC.nextLine();
                    for (i = 0; i <= 7; i++) {

                        if (result[i]>=70) {
                            System.out.println("Las personas que aprobaron son: " + name[i]);
                            System.out.println("");
                        } else {
                            System.out.println(" Ninguno paso la prueba");
                        }
                    }
                    break;
                }
            }
            System.out.println("Desea generar otra consulta?, true/false ");
            control = entryA.nextBoolean();
            if (control == false) {
                break;
            }
        }
    }
}
