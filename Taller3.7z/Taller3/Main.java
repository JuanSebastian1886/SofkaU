package com.sofkaU.Taller3;

import java.util.*;

public class Main {

    public static int option;
    public static boolean control;

    public static void main(String[] args) {
        Scanner entry = new Scanner(System.in);
        System.out.println("Menú de puntos ");
        System.out.println("1. Punto 1 ");
        System.out.println("2. Punto 2 ");
        System.out.println("3. Punto 3 ");
        System.out.println("4. Punto 4  ");
        System.out.println("5. Punto 5  ");
        System.out.println("6. Punto 6  ");
        System.out.println("7. Punto 7  ");
        System.out.println("8. Punto 8  ");
        System.out.println(" ");
        control = true;

        while (control == true) {

            System.out.println("Desea ver algún punto?, true/false ");
            control = entry.nextBoolean();
            System.out.println("");
            if (control == false) {
                break;
            }
            System.out.println("Ingrese la opción que desea: ");
            option = entry.nextInt();

            switch (option) {

                case 1: {
                    exercisesTaller3 p1 = new exercisesTaller3();
                    p1.punto1();
                    break;
                }
                case 2: {
                    exercisesTaller3 p2 = new exercisesTaller3();
                    p2.punto2();
                    break;
                }
                case 3: {
                    exercisesTaller3 p3 = new exercisesTaller3();
                    p3.punto3();
                    break;
                }
                case 4: {
                    exercisesTaller3 p4 = new exercisesTaller3();
                    p4.punto4();
                    break;
                }
                case 5: {
                    exercisesTaller3 p5 = new exercisesTaller3();
                    p5.punto5();
                    break;
                }
                case 6: {
                    exercisesTaller3 p6 = new exercisesTaller3();
                    p6.punto6();
                    break;
                }
                case 7: {
                    exercisesTaller3 p7 = new exercisesTaller3();
                    p7.punto7();
                    break;
                }
                case 8: {
                    exercisesTaller3 p8 = new exercisesTaller3();
                    p8.punto8();
                    break;
                }
                default:
                    System.out.println("Opcion no valida");

            }

        }

    }
}
