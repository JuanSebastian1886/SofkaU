package com.sofkaU.Taller4;

import java.util.*;

public class Main {

    public static int option;
    public static boolean control;

    public static void main(String[] args) {
        Scanner entry = new Scanner(System.in);
        System.out.println("Menú de puntos ");
        System.out.println("1. Punto 1 ");
        System.out.println("2. Punto 2 ");
        System.out.println("3. Punto 3 ");
        System.out.println("4. Punto 4  ");
        System.out.println("5. Punto 5  ");
        System.out.println(" ");
        control = true;

        while (control == true) {

            System.out.println("Desea ver algún punto?, true/false ");
            control = entry.nextBoolean();
            System.out.println("");
            if (control == false) {
                break;
            }
            System.out.println("Ingrese la opción que desea: ");
            option = entry.nextInt();

            switch (option) {

                case 1: {
                    exercisesTaller4 p1 = new exercisesTaller4();
                    p1.punto1();
                    System.out.println("");
                    break;
                }
                case 2: {
                    exercisesTaller4 p2 = new exercisesTaller4();
                    p2.punto2();
                    System.out.println("");
                    break;
                }
                case 3: {
                    exercisesTaller4 p3 = new exercisesTaller4();
                    p3.punto3();
                    System.out.println("");
                    break;
                }
                case 4: {
                    exercisesTaller4 p4 = new exercisesTaller4();
                    p4.punto4();
                    System.out.println("");
                    break;
                }
                case 5: {
                    exercisesTaller4 p5 = new exercisesTaller4();
                    p5.punto5();
                System.out.println("");
                    break;
                }               
                default:
                    System.out.println("Opcion no valida");

            }

        }

    }
}
