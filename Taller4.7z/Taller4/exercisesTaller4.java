package com.sofkaU.Taller4;

import java.util.*;

public class exercisesTaller4 {

    public String name;
    public int option, i, j, k, n, arrayP1, array,r,c;
    public boolean control;
    private Scanner entry = new Scanner(System.in);

    public void punto1() {
        int arrayP1[] = new int[5];

        for (int i = 0; i <= 4; i++) {
            System.out.println("Ingrese el valor de la posición " + i + " del arreglo");
            arrayP1[i] = entry.nextInt();
            System.out.println("");
        }
        for (int i = 0; i <= 4; i++) {
            System.out.println("[" + i + "]" + "=" + arrayP1[i]);
            System.out.println("");
        }
    }

    public void punto2() {
        int array[] = new int[20];
        int arrayP[] = new int[20];
        int arrayI[] = new int[20];
        int p = 0;
        int im = 0;

        Random rnd = new Random();
        System.out.println("");
        for (int i = 0; i <= 19; i++) {
            array[i] = rnd.nextInt(101);
            System.out.println(array[i]);
        }
        System.out.println("");
        for (int i = 0; i <= 19; i++) {
            if (array[i] % 2 == 0) {
                arrayP[p] = array[i];
                // System.out.print("Los numeros pares son: " + array[i]);
                p++;
            } else {
                arrayI[im] = array[i];
                // System.out.print("Los numeros impares son: " + array[i]);
                im++;
            }
        }
        if (p > 0) {
            for (int i = 0; i <= p - 1; i++) {
                System.out.println("Pares: " + arrayP[i]);
            }
        } else {
            System.out.print("no hay pares");
        }
        System.out.println("");

        if (im > 0) {
            for (int i = 0; i <= im - 1; i++) {
                System.out.println("impares: " + arrayI[i]);
            }
        } else {
            System.out.print("no hay impares");
        }
    }

    public void punto3() {
        System.out.println("los nuemros primos en el intervalo 1-1000 son: ");
        
        for (int i = 1; i <= 1000; i++) {
            int count = 0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    count++;
                }
            } 
            if (count == 2) {
                System.out.println(i);
            }
        }
    }
    public void punto4() {
        String matrix[][] = new String[4][5];
        
        matrix[0][0]= "01"; matrix[0][1]= "02";
        matrix[0][2]= "03"; matrix[0][3]= "04";
        matrix[0][4]= "05"; matrix[1][0]= "06";
        matrix[1][1]= "07"; matrix[1][2]= "08";
        matrix[1][3]= "09"; matrix[1][4]= "10";
        matrix[2][0]= "11"; matrix[2][1]= "12";
        matrix[2][2]= "13"; matrix[2][3]= "14";
        matrix[2][4]= "15"; matrix[3][0]= "16";
        matrix[3][1]= "17"; matrix[3][2]= "18";
        matrix[3][3]= "19"; matrix[3][4]= "20";
	
        for (int i = 0; i <= 3; i++) {
            System.out.println("");           
            for (int j = 0; j <= 4; j++) {            
                System.out.print(" "+matrix[i][j]+" ");                
            }
        }
        System.out.println("");
        for (int i = 0; i <= 0; i++) {
            System.out.println("");           
            for (int j = 0; j <= 4; j++) {            
                System.out.print(" "+matrix[i][j]+" ");                
            }
        }
        for (int i = 1; i <= 1; i++) {
            System.out.println("");           
            for (int j = 4; j >= 0; j--) {            
                System.out.print(" "+matrix[i][j]+" ");                
            }
        }
        for (int i = 2; i <= 2; i++) {
            System.out.println("");           
            for (int j = 0; j <= 4; j++) {            
                System.out.print(" "+matrix[i][j]+" ");                
            }
        }
        for (int i = 3; i <= 3; i++) {
            System.out.println("");           
            for (int j = 4; j >= 0; j--) {            
                System.out.print(" "+matrix[i][j]+" ");                
            }
        }
        System.out.println("");
    }
     public void punto5() {
        String matrix[][] = new String[12][12];
        int results[][] = new int[10][10];
        
        matrix[0][0]= "   "; matrix[0][1]= "   "; matrix[0][2]= "   "; matrix[0][3]= " C ";
        matrix[0][4]= " O "; matrix[0][5]= " L "; matrix[0][6]= " U "; matrix[0][7]= " M ";
        matrix[0][8]= " N "; matrix[0][9]= " A "; matrix[0][10]= " S "; matrix[0][11]= "   ";
       
        matrix[1][0]= "   "; matrix[1][1]= "   "; matrix[1][2]= "  0 "; matrix[1][3]= "   1 ";
        matrix[1][4]= "   2 "; matrix[1][5]= "   3 "; matrix[1][6]= "   4 "; matrix[1][7]= "   5 ";
        matrix[1][8]= "   6 "; matrix[1][9]= "   7 "; matrix[1][10]= "   8 "; matrix[1][11]= "   9 ";
        
        matrix[2][0]= "   "; matrix[2][1]= " 0 "; matrix[2][2]= " 1X1 "; matrix[2][3]= " 2X1 ";
        matrix[2][4]= " 3X1 "; matrix[2][5]= " 4X1 "; matrix[2][6]= " 5X1 "; matrix[2][7]= " 6X1 ";
        matrix[2][8]= " 7X1 "; matrix[2][9]= " 8X1 "; matrix[2][10]= " 9X1 "; matrix[2][11]= " 10X1 ";
        
        matrix[3][0]= "   "; matrix[3][1]= " 1 "; matrix[3][2]= " 2X1 "; matrix[3][3]= " 2X2 ";
        matrix[3][4]= " 3X2 "; matrix[3][5]= " 4X2 "; matrix[3][6]= " 5X2 "; matrix[3][7]= " 6X2 ";
        matrix[3][8]= " 7X2 "; matrix[3][9]= " 8X2 "; matrix[3][10]= " 9X2 "; matrix[3][11]= " 10X2 ";
        
        matrix[4][0]= " F "; matrix[4][1]= " 2 "; matrix[4][2]= " 3X1 "; matrix[4][3]= " 3X2 ";
        matrix[4][4]= " 3X3 "; matrix[4][5]= " 4X3 "; matrix[4][6]= " 5X3 "; matrix[4][7]= " 6X3 ";
        matrix[4][8]= " 7X3 "; matrix[4][9]= " 8X3 "; matrix[4][10]= " 9X3 "; matrix[4][11]= " 10X3 ";
        
        matrix[5][0]= " I "; matrix[5][1]= " 3 "; matrix[5][2]= " 1X4 "; matrix[5][3]= " 2X4 ";
        matrix[5][4]= " 3X4 "; matrix[5][5]= " 4X4 "; matrix[5][6]= " 5X4 "; matrix[5][7]= " 6X4 ";
        matrix[5][8]= " 7X4 "; matrix[5][9]= " 8X4 "; matrix[5][10]= " 9X4 "; matrix[5][11]= " 10X4 ";
       
        matrix[6][0]= " L "; matrix[6][1]= " 4 "; matrix[6][2]= " 1X5 "; matrix[6][3]= " 2X5 ";
        matrix[6][4]= " 3X5 "; matrix[6][5]= " 4X5 "; matrix[6][6]= " 5X5 "; matrix[6][7]= " 6X5 ";
        matrix[6][8]= " 7X5 "; matrix[6][9]= " 8X5 "; matrix[6][10]= " 9X5 "; matrix[6][11]= " 10X5 ";
        
        matrix[7][0]= " A "; matrix[7][1]= " 5 "; matrix[7][2]= " 1X6 "; matrix[7][3]= " 2X6 ";
        matrix[7][4]= " 3X6 "; matrix[7][5]= " 4X6 "; matrix[7][6]= " 5X6 "; matrix[7][7]= " 6X6 ";
        matrix[7][8]= " 7X6 "; matrix[7][9]= " 8X6 "; matrix[7][10]= " 9X6 "; matrix[7][11]= " 10X6 ";
        
        matrix[8][0]= " S "; matrix[8][1]= " 6 "; matrix[8][2]= " 1X7 "; matrix[8][3]= " 2X7 ";
        matrix[8][4]= " 3X7 "; matrix[8][5]= " 4X7 "; matrix[8][6]= " 5X7 "; matrix[8][7]= " 6X7 ";
        matrix[8][8]= " 7X7 "; matrix[8][9]= " 8X7 "; matrix[8][10]= " 9X7 "; matrix[8][11]= " 10X7 ";
        
        matrix[9][0]= "   "; matrix[9][1]= " 7 "; matrix[9][2]= " 1X8 "; matrix[9][3]= " 2X8 ";
        matrix[9][4]= " 3X8 "; matrix[9][5]= " 4X8 "; matrix[9][6]= " 5X8 "; matrix[9][7]= " 6X8 ";
        matrix[9][8]= " 7X8 "; matrix[9][9]= " 8X8 "; matrix[9][10]= " 9X8 "; matrix[9][11]= " 10X8 ";
        
        matrix[10][0]= "   "; matrix[10][1]= " 8 "; matrix[10][2]= " 1X9 "; matrix[10][3]= " 2X9 ";
        matrix[10][4]= " 3X9 "; matrix[10][5]= " 4X9 "; matrix[10][6]= " 5X9 "; matrix[10][7]= " 6X9 ";
        matrix[10][8]= " 7X9 "; matrix[10][9]= " 8X9 "; matrix[10][10]= " 9X9 "; matrix[10][11]= " 10X9 ";
        
        matrix[11][0]= "   "; matrix[11][1]= " 9 "; matrix[11][2]= " 1X10"; matrix[11][3]= " 2X10";
        matrix[11][4]= " 3X10"; matrix[11][5]= " 4X10"; matrix[11][6]= " 5X10"; matrix[11][7]= " 6X10";
        matrix[11][8]= " 7X10"; matrix[11][9]= " 8X10"; matrix[11][10]= " 9X10"; matrix[11][11]= " 10X10";

         for (int i = 0; i <= 11; i++) {
             System.out.println("");
             for (int j = 0; j <= 11; j++) {
                 System.out.print(" " + matrix[i][j] + " ");
             }
         }
        System.out.println("");
        
        System.out.println("Ingrese la fila que desea consultar ");
        r=entry.nextInt();
        System.out.println("Ingrese la columna que desea consultar ");
        c=entry.nextInt();
        
        results[0][0]= 1; results[0][1]= 2; results[0][2]= 3; results[0][3]= 4;
        results[0][4]= 5; results[0][5]= 6; results[0][6]= 7; results[0][7]= 8;
        results[0][8]= 9; results[0][9]= 10; 
        
        results[1][0]= 2; results[1][1]= 4; results[1][2]= 6; results[1][3]= 8;
        results[1][4]= 10; results[1][5]= 12; results[1][6]= 14; results[1][7]= 16;
        results[1][8]= 18; results[1][9]= 20; 
       
        results[2][0]= 3; results[2][1]= 6; results[2][2]= 9; results[2][3]= 12;
        results[2][4]= 15; results[2][5]= 18; results[2][6]= 21; results[2][7]= 24;
        results[2][8]= 27; results[2][9]= 30; 
       
        results[3][0]= 4; results[3][1]= 8; results[3][2]= 12; results[3][3]= 16;
        results[3][4]= 20; results[3][5]= 24; results[3][6]= 28; results[3][7]= 32;
        results[3][8]= 36; results[3][9]= 40; 
       
        results[4][0]= 5; results[4][1]= 10; results[4][2]= 15; results[4][3]= 20;
        results[4][4]= 25; results[4][5]= 30; results[4][6]= 35; results[4][7]= 40;
        results[4][8]= 45; results[4][9]= 50; 
       
        results[5][0]= 6; results[5][1]= 12; results[5][2]= 18; results[5][3]= 24;
        results[5][4]= 30; results[5][5]= 36; results[5][6]= 42; results[5][7]= 48;
        results[5][8]= 54; results[5][9]= 60; 
       
        results[6][0]= 7; results[6][1]= 14; results[6][2]= 21; results[6][3]= 28;
        results[6][4]= 35; results[6][5]= 42; results[6][6]= 49; results[6][7]= 56;
        results[6][8]= 63; results[6][9]= 70; 
       
        results[7][0]= 8; results[7][1]= 16; results[7][2]= 24; results[7][3]= 32;
        results[7][4]= 40; results[7][5]= 48; results[7][6]= 56; results[7][7]= 64;
        results[7][8]= 72; results[7][9]= 80; 
       
        results[8][0]= 9; results[8][1]= 18; results[8][2]= 27; results[8][3]= 36;
        results[8][4]= 45; results[8][5]= 54; results[8][6]= 63; results[8][7]= 72;
        results[8][8]= 81; results[8][9]= 90; 
       
        results[9][0]= 10; results[9][1]= 20; results[9][2]= 30; results[9][3]= 40;
        results[9][4]= 50; results[9][5]= 60; results[9][6]= 70; results[9][7]= 80;
        results[9][8]= 90; results[9][9]= 100; 
       
        
        System.out.println("El resultado es: "+ results[r][c]);
        System.out.println(" ");
        
        
    }
}
