const validar =()=>{

    var name= document.getElementById("name");
    var email= document.getElementById("email");
    var subject= document.getElementById("subject");
    var mesage= document.getElementById("mesage");
    var form= document.getElementById("form");

    // según la especificación HTML5
    const nameRegExp=/^[a-zA-ZÀ-ÿ\s]{1,30}$/;
    const subjectRegExp=/^[a-zA-ZÀ-ÿ\s]{1,30}$/;
    const mesageRegExp=/^[a-zA-ZÀ-ÿ\s]{1,30}$/;
    const emailRegExp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    form.addEventListener("submit" ,e =>{
        e.preventDefault();

        if(name.value.lenght ==0 && email.value.lenght ==0  && subject.value.lenght ==0
            && mesage.value.lenght ==0 ){
                document.getElementById("alert").innerHTML= "Debe llenar todos los campos";
                form.reset();
        }else if(name.lenght ==0){
            document.getElementById("alert").innerHTML= "Debe llenar su nombre";
                name.focus();
        
        }else if(email.lenght ==0){
            document.getElementById("alert").innerHTML= "Debe poner su correo";
                email.focus();
        
        }else if(subject.lenght ==0){
            document.getElementById("alert").innerHTML= "Debe poner el asunto";
                subject.focus();       
        }else if(mesage.lenght ==0){
            document.getElementById("alert").innerHTML= "Debe poner un mensaje";
                mesage.focus();
        }
        else if(!nameRegExp.test(name.value)){
            document.getElementById("alert").innerHTML= "El campo Nombre debe llenarse";
        }
        else if(!emailRegExp.test(email.value)){
            document.getElementById("alert").innerHTML= "El formato de correo es incorrecto";
        }
        else if(!subjectRegExp.test(subject.value)){
            document.getElementById("alert").innerHTML= "El campo Asunto debe llenarse";
        }
        else if(!mesageRegExp.test(mesage.value)){
            document.getElementById("alert").innerHTML= "El campo Mensaje debe llenarse";
        }
        else{
            console.log("name:", name.value);
            console.log("email:", email.value);
            console.log("subject:", subject.value);
            console.log("mesage:", mesage.value);       
        }
    });
}

const data =()=>{
    
}