const main=()=>{
    const index= document.querySelectorAll(".fruit");
    const btn_item= document.querySelector("#btn-item");

    btn_item.addEventListener("click", ()=>{
        console.log(index);
        index.forEach(element => {
            if(element.classList.contains('even')){
                element.classList.remove('even')
                element.classList.add('odd')
            }else{
                element.classList.remove('odd')
                element.classList.add('even')
            }            
        });
    })
}