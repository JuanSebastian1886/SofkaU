const matrix1 =() =>{
    matrix[0,0]<- '01';
    matrix[0,1]<- '02';
    matrix[0,2]<- '03';
    matrix[0,3]<- '04';
    matrix[0,4]<- '05';
    matrix[1,0]<- '06';
    matrix[1,1]<- '07' ;
     }